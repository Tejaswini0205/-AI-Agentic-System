from langgraph.graph import StateGraph, END
from agents.researcher_agent import get_research_agent
from agents.drafter_agent import get_drafter_agent

research_agent = get_research_agent()
drafter_agent = get_drafter_agent()

class AgentState(dict):
    pass

def run_research(state: AgentState):
    topic = state["topic"]
    result = research_agent.run(f"Research this topic: {topic}")
    state["research_summary"] = result
    return state

def run_drafting(state: AgentState):
    draft = drafter_agent.run({"research_summary": state["research_summary"]})
    state["final_answer"] = draft
    return state

def build_graph():
    builder = StateGraph(AgentState)
    builder.add_node("research", run_research)
    builder.add_node("draft", run_drafting)

    builder.set_entry_point("research")
    builder.add_edge("research", "draft")
    builder.add_edge("draft", END)

    return builder.compile()