from langchain.chat_models import ChatOpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv

load_dotenv()

def get_drafter_agent():
    prompt = PromptTemplate(
        input_variables=["research_summary"],
        template="""
Based on the research below, write a detailed, structured, and informative response:

Research:
{research_summary}
"""
    )
    
    llm = ChatOpenAI(temperature=0.5, model="gpt-3.5-turbo")
    return LLMChain(prompt=prompt, llm=llm)