from langchain.tools.tavily_search import TavilySearchResults
from langchain.agents import initialize_agent, Tool
from langchain.chat_models import ChatOpenAI
from dotenv import load_dotenv
import os

load_dotenv()

def get_research_agent():
    search_tool = TavilySearchResults(max_results=5)
    tools = [Tool.from_function(search_tool, name="web-search", description="Web search tool for research.")]
    
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo")
    
    return initialize_agent(tools, llm, agent="chat-zero-shot-react-description", verbose=True)