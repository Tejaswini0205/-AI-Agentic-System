# 🧠 Deep Research AI Agentic System

This project is a dual-agent AI system for deep research and answer drafting using LangGraph, LangChain, and Tavily Search API. It features:

- 🌐 Web crawling & research using Tavily
- 🧠 Dual agents (Research + Drafting)
- 📊 LangGraph orchestration of agents
- ⚙️ Simple command-line interface

---

## 📁 Project Structure

```
deep-research-agent/
│
├── agents/
│   ├── researcher_agent.py      # Tavily-based research agent
│   └── drafter_agent.py         # Answer drafting agent using OpenAI
│
├── graph/
│   └── deep_research_graph.py   # LangGraph orchestration
│
├── main.py                      # Entry point for running the system
├── requirements.txt             # Dependencies
├── .env                         # API keys (OpenAI & Tavily)
└── README.md                    # This file
```

---

## 🚀 Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/your-username/deep-research-agent.git
cd deep-research-agent
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Set up API keys

Create a `.env` file in the root directory:

```env
OPENAI_API_KEY=your_openai_api_key
TAVILY_API_KEY=your_tavily_api_key
```

---

## 🧪 Running the Project

```bash
python main.py
```

You'll be prompted to enter a **research topic**. The AI agents will:

1. Use Tavily to research the topic
2. Summarize & process the results
3. Draft a high-quality, structured answer

---

## 🛠️ Dependencies

```txt
langchain
langgraph
openai
tavily-python
python-dotenv
```

Install via:

```bash
pip install -r requirements.txt
```

---

## 🧠 Agent Workflow

- **Researcher Agent**: Uses Tavily API for web searches and gathers structured summaries.
- **Drafter Agent**: Uses OpenAI’s GPT to draft a final answer using the research output.
- **LangGraph**: Orchestrates the flow using nodes and state transitions.

---

## 📸 Demo

```bash
Enter your research topic: renewable energy impact in 2025

✅ FINAL DRAFTED ANSWER:
In 2025, renewable energy continues to shape the global energy market...
```

---

## 📌 Notes

- Make sure your OpenAI and Tavily API keys are active and valid.
- Tavily has a free tier but usage limits may apply.

---

## 📜 License

MIT License

---

## 🤝 Contributing

PRs welcome! Feel free to fork, tweak, and improve the system for new agent types or workflows.