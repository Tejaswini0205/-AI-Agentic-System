from graph.deep_research_graph import build_graph

if __name__ == "__main__":
    topic = input("Enter your research topic: ")
    graph = build_graph()
    final_state = graph.invoke({"topic": topic})
    
    print("\n✅ FINAL DRAFTED ANSWER:")
    print(final_state["final_answer"])